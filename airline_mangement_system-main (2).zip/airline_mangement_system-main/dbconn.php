<?php
$sever = "localhost";
$username = "root";
$password = "";
$database = "ticket_booking";
$conn = mysqli_connect($sever,$username,$password,$database);
if (!$conn) {
    echo "Not done";
}
?>