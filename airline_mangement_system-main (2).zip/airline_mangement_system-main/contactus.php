<?php
include("dbconn.php");
session_start();
if (isset($_POST["send"])) {
    // echo 'hi';
	$email = mysqli_real_escape_string($conn,$_POST["email"]);
	$name = mysqli_real_escape_string($conn,$_POST["name"]);
	$country = mysqli_real_escape_string($conn,$_POST["country"]);
	$msg = mysqli_real_escape_string($conn,$_POST["msg"]);
    $insertquery = "INSERT INTO `contact` (`Id`, `Email`, `Name`, `Country`, `Msg`) VALUES (NULL, '$email', '$name', '$country', '$msg')";
    // $insertquery = "INSERT INTO `users` (`sr no`, `name`, `Branch`, `email`, `password`, `status`, `token`,`gender`) VALUES (NULL, '$username', '$Branch', '$email', '$pass', 'inactive', '$token','$gender')";
    $iquery = mysqli_query($conn,$insertquery);
}
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Contact</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="myjs.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Poppins">

        <link rel="stylesheet" href="mycss.css">
    </head>
<style type="text/css">
            label{
            color: white;
        }


        
</style>
    <body>
                <nav class="navbar navbar-inverse" style="border-radius:0px !important; margin:0;border: 0">
                    <div class="container-fluid">
                        <div class="navbar-header">
                          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>                       
                          </button>
                          <a class="navbar-brand" href="index.html">Airline</a>
                        </div>
                        <div class="collapse navbar-collapse" id="myNavbar">
                            <ul class="nav navbar-nav">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="booking.php">Booking</a></li>
                                <li><a href="bus.html">Bus</a></li>
                                <li><a href="about.html">About Us</a></li>
                                <li class="active" ><a href="contactus.html">Contact Us</a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></a></li>
                            </ul>
                            
                            <form class="navbar-form navbar-right">
                              <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search">
                                <div class="input-group-btn">
                                  <button class="btn btn-default" type="submit">
                                    <i class="glyphicon glyphicon-search"></i>
                                  </button>
                                </div>
                              </div>
                            </form>
                        </div>  
                    </div>
                </nav>
                

                <div class="background-wrapper" style="background-image: url(./GettyImages-471884691-81dbf983fc8144cc82caccf1ef8b91d8.jpg);">
                
                <!--header-->

                <div class="container-fluid">
                    <header>
                        <h2 style="font-size: xx-large; font-weight: 700; color: black;" >Contact Us</h2>
                        <hr>
                    </header>

                    <!--panel-->
                    <div class="col-sm-6 col-sm-offset-3">
                        <div class="panel-group panel-transparent">
                            <div class="panel panel-default panel-transparent">
                                <div class="panel-heading">
                                    <legend style="text-align: center; font-weight: bolder; font-size: xx-large; color: black;">Contact Information</legend>
                                </div>
                                <div class="panel-body">
                                    <form class="form-horizontal" method="POST"  style="padding: 0 5rem 0 5rem; width: 100%; height:100%">
                                            <div class="form-group">
                                                <label for="email">Email</label>
                                                <input type="email" class="form-control trans-input-area" placeholder="Email" name = "email"  id="email" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="name">Name</label>
                                                <input type="text" class="form-control trans-input-area" placeholder="Name" name="name" id="name" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="Country">Country</label>
                                                <input type="text" class="form-control trans-input-area" placeholder="Country" name="country" id="Country" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="subject">Message</label>
                                                <textarea id="subject" class="trans-input-area" placeholder="Write something.." name="msg" style="height:200px; width: 100%"></textarea>
                                            </div>
                                            <div class="input-group-btn" style="margin: 0;padding: 0;">
                                                <button class="btn btn-block trans-input-area" name = "send" type="submit"><i  class="glyphicon glyphicon-send"></i> Send</button>
                                            </div>
                                     </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>

            <!-- Footer -->
            <footer id="footer">
                <div class="container-fluid">
                    <ul class="icons">
                        <li><a href="#" class="fa fa-twitter" style="color: grey"></a></li>
                        <li><a href="#" class="fa fa-facebook" style="color: grey"></a></li>
                        <li><a href="#" class="fa fa-instagram" style="color: grey"></a></li>
                        <li><a href="#" class="fa fa-envelope" style="color: grey"></a></li>
                    </ul>
                </div>
                <div class="copyright">
                    &copy; Airline. All rights reserved.
                </div>
            </footer>

            

    </body>
</html>





