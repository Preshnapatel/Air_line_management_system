<?php
include("dbconn.php");
session_start();
$_SESSION["Invaild password"] = 0;
$_SESSION["emailnotExits"] = 0;
if (isset($_POST["signin"])) {
    // echo 'hi';
	$email = mysqli_real_escape_string($conn,$_POST["email1"]);
    $lowerCaseEmail = strtolower($email);
    $emailquery = "SELECT * FROM `users` where email_id = '$lowerCaseEmail'";
    echo $email;
    echo $lowerCaseEmail;

    //For Protection Of Mysqli injection (mysqli_real_escape_string)
    $password = mysqli_real_escape_string($conn,$_POST["password1"]);
    echo $password;
    // $pass = password_hash($password,PASSWORD_BCRYPT);
    $query = mysqli_query($conn,$emailquery);
    $emailcount = mysqli_num_rows($query);
	if ($emailcount > 0) {
		$row = mysqli_fetch_assoc($query);
			if ($password == $row["password"]) {
			// if (password_verify($password, $row["password"])) {
				// echo 'Password is valid!';
    echo 'Pass';
    if($lowerCaseEmail = "keval@gmail.com"){
        header('location:about_us.html');
    }
    else{
        header('location:index.php');
    }
} else {
                echo 'Not';
				// echo 'Invalid password.';
		        $_SESSION["Invaild password"] = 1;
			}
    }
    else{
		// echo "email not exits";
    // echo 'More';
		$_SESSION["emailnotExits"] = 1;
	}
}
$_SESSION["personal_email"] = 0;
$_SESSION["passnotmatch"] = 0;
$_SESSION["passnot8"] = 0;
$_SESSION["emailExits"] = 0;
if (isset($_POST["signup"])) {
    $email = mysqli_real_escape_string($conn,$_POST["email"]);
    $lowerCaseEmail = strtolower($email); 
    $username = mysqli_real_escape_string($conn,$_POST["Name"]);
    $password = mysqli_real_escape_string($conn,$_POST["password"]);
    $emailquery = "SELECT * FROM `users` where email_id = '$lowerCaseEmail'";
    $query = mysqli_query($conn,$emailquery);
    $emailcount = mysqli_num_rows($query);
    if ($emailcount > 0) {
        // echo "email already exits";
        $_SESSION["emailExits"] = 1;
    }
    else{
            $insertquery = "INSERT INTO `users` (`U_id`, `name`, `password`, `email_id`) VALUES (NULL, '$username','$password','$lowerCaseEmail')";
            // $insertquery = "INSERT INTO `users` (`sr no`, `name`, `Branch`, `email`, `password`, `status`, `token`,`gender`) VALUES (NULL, '$username', '$Branch', '$email', '$pass', 'inactive', '$token','$gender')";
            $iquery = mysqli_query($conn,$insertquery);
            if ($iquery) {
                // We are Sending Email.........
                // $subject = "College Coner Account Activation ";
                // $sender_email = "From: collegecorner4217@gmail.com";
                // if (mail($email, $subject, $body, $sender_email)) {
                //     echo 'Email successfully sent to '.$email.'';
		        	header("location:loading.php");
                    // header("location:activate.php");
                // } else {echo "Email sending failed...";}
            }
            else{
                echo"signUp Fail Due To Techincal Problem";
            }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <meta name="viewport" content="width=device-width", initial-scale="1.0">
    <title>Document</title>
</head>

<style>
    @import url('https://fonts.googleepis.com/css?family=Poppins:200,300,400,500,600,700,800,900&display=swap');
    
*
{
    margin: 0px;
    padding: 0px;
    box-sizing: border-box;
    font-family: 'Poppins',sans-serif;
    
}
body
{
  min-height: 100vh;
  display:flex;
  align-items: center;
  justify-content: center;
  background-color: #242225;
  padding: 30px;
}
.container
{ 
    position: relative;
    max-width : 850px;
    width: 100%;
    background-color: #fff;
    padding: 40px 30px;
    box-shadow: 0 5px 10px rgba(0,0,0,0.2);
    perspective: 2700px;

}
.container .cover
{
    position: absolute;
    top:0;
    left:50%;
    height: 100%;
    width: 50%;
    /* background: red; */
    z-index: 98;
    transition: all 1s ease;
    transform-origin: left;
    transform-style: preserve-3d;
}
.container .cover::before
{
    content:'';
    position: absolute;
    height: 100%;
    width: 100%;
    background: #3e3e3f;
    opacity: 0.5;
    z-index: 100;
}
.container #flip:checked ~ .cover{
    transform: rotateY(-180deg);
}
.container .cover img
{
    position: absolute;
    height: 100%;
    width: 100%;
    object-fit: cover;
    z-index: 12;
    backface-visibility: hidden;
}
 .container .cover .back .backimg
{
    transform: rotateY(180deg);
} 
.container .cover .text
{
    position:absolute;
    z-index: 111;
    height: 100%;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}
.cover .text .text-1,
.cover .text .text-2
{
   font-size: 26px;
   font-weight: 600;
   color: #fff;
   text-align: center;
   backface-visibility: hidden;
}
.cover .text .text-2
{
    font-size: 15px;
    font-weight: 500px;
}
.container form
{
    height: 100%;
    width:100%;
    background: #fff;
}
.container .form-content
{
   display: flex;
   align-items: center;
   justify-content: center;
   justify-content: space-around;
}
.form-content .login-form,
.form-content .login-form
{
  width: calc(100% / 2 - 25px);
  /* background-color: red; */
}
form .form-content .title
{
    position: relative;
    font-size: 24px;
    font-weight: 500;
    color: #333;
}
form .form-content .title:before
{
    content:'';
    position: absolute;
    left: 0;
    bottom: 0;
    height: 3px;
    width: 25px;
    background: #3e2d55;
}
form .form-content .title:after
{
    content:'';
    position: absolute;
    left: 0;
    bottom: 0;
    height: 3px;
    width: 25px;
    background: #28232e;
}
form .signup-form  .title:before
{
  width: 20px;
}
form .form-content .input-boxes
{
    margin-top: 30px;
}
form .form-content .input-box
{   
    display:flex;
    align-items: center;
    height: 50px;
    width: 100%;
    margin:  10px 0;
    position: relative;
}
.form-content .input-box input{
    height: 100%;
    width: 100%;
    outline: none;
    border: none;
    padding: 0 30px;
    font-size: 17px;
    font-weight: 500;
    border-bottom: 2px solid rgba(0,0,0,2);
    transition: all 0.3s ease;
}
.form-content .input-box input:focus,
.form-content .input-box input:valid
{
    /* border: 2px solid; */
    border-color: #7d2ae8;
}
.form-content .input-box i
{
    position: absolute;
    color: #7d2ae8;
    font-size: 17px;
}
form .form-content .text
{
    font-size: 14px;
    font-weight: 500;
    color: #333;
}
form .form-content .text a
{
    text-decoration: none;
}
form .form-content .text a:hover
{
    text-decoration: underline;
}
form .form-content  .button input
{
    color: #fff;
    margin-top: 40px;
}    
form .form-content  .button input
{
    color: #fff;
    background: #7d2ae8;
    border-radius: 6px;
    padding: 0;
    cursor: pointer;
}
form .form-content .button input:hover
{
    background: #5b13b9;
}
form .form-content label
{
    color: #5b13b9;
    cursor: pointer;
}
from .form-content label:hover
{
  text-decoration: underline;
}
form .form-content .login-text,
form .form-content .sign-up-text
{
 text-align: center;
 margin-top: 25px;
}
.container #flip
{
    display: none;
}
@media(max-width: 730px)
{
    .container .cover
    {
        display: none;
    }
    .form-content .login-form,
    .form-content .signup-form
    {
        width: 100%;
    }
    .form-content .signup-form
    {
        display:none
    }
    .container #flip:checked ~ form .signup-form
    {
      display: block;
    }
    .container #flip:checked ~ form .login-form
    {
      display: none;
    }
}

</style>
<body>
    <div class="container">
        <input type="checkbox" id="flip">
        <div class="cover">
        <div class="front">
            <img src="./airline.jpg" alt="" >
            <div class="text">
                <span class="text-1">airline booking</span>
                <span class="text-2">booking available</span>

            </div>
        </div>
        <div class="back">
            <img class="backImg" src="./airline.jpg" alt="" >
            <!-- <div class="text">
                <span class="text-1">airline b</span>
                <span class="text-2">booking available</span>

            </div> -->
        </div>
       </div> 
        <form method="POST">
         <div class="form-content">
            <div class="login-form">
                <div class="title">login</div>
                <div class="input-boxes">
                <div class="input-box">
                <i class="fas fa-envelope"></i>
                <input type="email" placeholder="Enter your email" name="email1">
            </div>
            <div class="input-box">
                <i class="fas fa-lock"></i>
                <input type="password" placeholder="Enter your Password " name = "password1">
            </div>
            <div class="text"><a href="#">forgot password?</a></div>
            <div class=" button input-box">
                <input type="submit" value="submit" name = "signin">
            </div>
            <br>
            <div class="text login-text">don't have an account? <label for="flip">Signup now</label></div>
    </div>
    </div>
    <div class="signup-form">
        <div class="title">Signup</div>
        <div class="input-boxes">
        <div class="input-box">
        <i class="fas fa-user"></i>
        <input type="text" placeholder="Enter your name" name="Name">
    </div>
    <div class="input-box">
        <i class="fas fa-envelope"></i>
        <input type="text" placeholder="Enter your email" name="email">
    </div>
    <div class="input-box">
        <i class="fas fa-lock"></i>
        <input type="password" placeholder="Enter your Password " name="password">
    </div>
    <div class=" button input-box">
        
        <input type="submit" value="submit" name="signup">
    </div>
    <br>
    <div class="text sign-up-text">Already have an account? <label for="flip">Login now</label></div>
    </div>
    </div>
         </div>
</form>
</div>    
</body>
</html>


